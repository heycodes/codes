<?php
echo gethostbyname ($_GET['url']);
?>
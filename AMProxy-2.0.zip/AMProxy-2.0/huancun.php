<?php
	//清理缓存
	header("Content-type: text/html; charset=utf-8");
	//验证IP权限
	$ips = '|123.182.246.130|123.182.246.131|123.182.246.132|123.182.246.133|123.182.246.134|';
	if(strpos($ips, $_SERVER['REMOTE_ADDR'])){
		if($_GET['auth'] == 'ganen888'){
			$cmd = 'cd /home/amproxy_cache/;dir;rm -rf *;';
			exec($cmd, $tmp, $result_change);
			echo '待删除缓存:'.$tmp[0].'<br />';
			//print_r($result_change).'<br />';
			exit('缓存删除成功!');
		}else{
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>缓存清除</title>
</head>

<body>
请输入验证密码：<br />
<form id="form1" name="form1" method="get">
<input name="auth" type="text" /> <input type="submit" />
</form>
</body>
</html>
<?php
		}
	}else{
		header('HTTP/1.1 404 Not Found');
		header("status: 404 Not Found");
		exit;
	}
?>